import {useState} from 'react'
import './App.css'

function App(){
  //Logic goes here
  // STATE for text input box and list of task
  const [inputValue, setInputValue]= useState("")
  const [task, setTasks]= useState([]);

  const addTask = () => {
    if (inputValue.trim() === "") return;
      //add new task
    setTasks([...task, inputValue]);
    //clear
    setInputValue("");
  };

  const deleteTask = (indexToDelete) => {
    //Create new array excluding item
    const newTasks = task.filter((_, index) => index !== indexToDelete);
    setTasks(newTasks);

  };

  return (
    <div className="bg-[#A99A8E] p-17 rounded-xl w-full max-w-md mx-auto ">
      <h1 className="font-sans font-bold mb-3">TaskMaster</h1>
       <div className="input-group">
        <input type="text"
        className="border p-2 rounded"
        placeholder="Enter a Task..."
        value={inputValue}
        onChange={(e) => setInputValue(e.target.value)}/>
        <button className="px-4 rounded"
        onClick={addTask}>Add</button>
       </div>

       <ul className='font-sans font-bold mt-4'>
        {task.map((task, index)=>(
          <li key={index}>
            {task}
            <button className="delete.btn"
            onClick={() => deleteTask(index)}>
              Delete
              </button>
              </li>
        ))}
       </ul>
    </div>
  )
}
export default App